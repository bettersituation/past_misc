/*
 * Name: 조태희
 * Student ID: 2011131055
 */

public class CircularLinkedList<T>
{
    private Node<T> head;
    private int size;

    /*
     * Constructor for our Circular Linked List
     *
     * Initialize the instance variables to their default values
     */
    public CircularLinkedList()
    {
        head = null;
        size = 0;
    }

    /*
     * insert
     *
     * Insert a new node with the specified data into the specified index
     *
     * index - int; the location in which to insert the new node (indexed
     *              from 0)
     *
     * data - T; the data to be stored in the newly created node
     *
     * Note:  If the index is out of range ([0, size]), nothing should be
     *        inserted.
     *
     * Note: If the list is not empty and you insert at index 0, it should
     *       be inserted before the head and become the new head. However, if
     *       you insert at index |size|, it should be inserted before the head
     *       but should NOT become the new head.
     */
    public void insert(int index, T data)
    {
        if (index >= 0 && index <= this.size) {
            Node<T> newNode = new Node<T>(data);
            
            if (this.size == 0) {
                this.head = newNode;
                newNode.next = newNode;
                this.size++;

            } else {
                Node<T> prevNode = this.head;
                Node<T> currentNode = this.head;
                int i = 0;

                while (i < index) {
                    prevNode = currentNode;
                    currentNode = currentNode.next;
                    i++;
                }

                prevNode.next = newNode;
                newNode.next = currentNode;
                this.size++;

                if (index == 0) {
                    this.head = newNode;
                }
            }
        }
    }

    /*
     * insertAtHead
     *
     * Insert a new node at the head with the specified data
     *
     * data - T; the data to be stored in the newly created node
     *
     * Note: This should work even if the list is empty.
     */
    public void insertAtHead(T data)
    {
        Node<T> newNode = new Node<T>(data);

        if (this.head == null) {
            this.head = newNode;
            newNode.next = newNode;
        
        } else {
            Node<T> tailNode = this.head;
            
            while (true) {
                if (tailNode.next.equals(this.head)) {
                    break;
                }
                tailNode = tailNode.next;
            }

            newNode.next = this.head;
            this.head = newNode;
            tailNode.next = this.head;
        }
        this.size++;
    }

    /*
     * insertAtTail
     *
     * Insert a new node at the tail with the specified data
     *
     * data - T; the data to be stored in the newly created node
     *
     * Note: This should insert even if the list is empty.
     */
    public void insertAtTail(T data)
    {
        Node<T> newNode = new Node<T>(data);

        if (this.head == null) {
            this.head = newNode;
            newNode.next = newNode;
        
        } else {
            Node<T> tailNode = this.head;
            int i = 0;

            while (i < this.size -1) {
                i++;
                tailNode = tailNode.next;
            }

            tailNode.next = newNode;
            newNode.next = this.head;
        }
        this.size++;
    }

    /*
     * remove
     *
     * Remove the first node with the specified data, if it exists
     *
     * data - T; the data to find and remove from the list
     *
     * Note: You should use x.equals(y) to compare generic data
     */
    public void remove(T data)
    {
        if (this.head != null) {
            Node<T> currentNode = this.head;
            Node<T> prevNode = this.head;
            boolean e = false;

            while (true) {
                if (data.equals(currentNode.data)) {
                    e = true;
                    break;
                }

                if (currentNode.next.equals(this.head)) {
                    break;
                }

                prevNode = currentNode;
                currentNode = currentNode.next;
            }

            if (e) {
                if (currentNode.equals(this.head)) {
                    
                    while (true) {
                        if (prevNode.next.equals(this.head)) {
                            break;
                        }
                        prevNode = prevNode.next;
                    }

                    if (prevNode.equals(currentNode)) {
                        this.head = null;
                    } else {
                        this.head = currentNode.next;
                        prevNode.next = this.head;
                    }

                } else {
                    prevNode.next = currentNode.next;
                }
                this.size--;
            }
        }
    }

    /*
     * removeIndex
     *
     * Remove the node at the specified index
     *
     * index - int; the index to remove from
     *
     * Note: If the index is out of range do nothing
     */
    public void removeIndex(int index)
    {
        if (index >= 0 && index < this.size) {
            Node<T> currentNode = this.head;
            Node<T> prevNode = this.head;

            if (index == 0) {

                if (this.size == 1) {
                    this.head = null;
                } else {

                    while (true) {
                        if (prevNode.next.equals(this.head)) {
                            break;
                        }
                    prevNode = prevNode.next;
                    }

                    this.head = currentNode.next;
                    prevNode.next = this.head;
                }
            } else {
                int i = 0;

                while (i < index -1) {
                    i++;
                    prevNode = prevNode.next;
                    currentNode = currentNode.next;
                }
                currentNode = currentNode.next;
                currentNode = currentNode.next;

                prevNode.next = currentNode;
            }
            this.size--;
        }
    }

    /*
     * removeFromHead
     *
     * Remove the head node of the list, if it exists
     */
    public void removeFromHead()
    {
        if (this.size == 1) {
            this.head = null;
            this.size--;

        } else if (this.size > 1) {
            Node<T> currentNode = this.head;
            Node<T> tailNode = this.head;

            while (true) {
                if (tailNode.next.equals(this.head)) {
                    break;
                }
                tailNode = tailNode.next;
            }

            currentNode = currentNode.next;
            this.head = currentNode;
            tailNode.next = this.head;
            this.size--;
        }
    }

    /*
     * removeFromTail
     *
     * Remove the tail node of the list, if it exists
     */
    public void removeFromTail()
    {
        if (this.size == 1) {
            this.head = null;
            this.size--;
        } else if (this.size == 2) {
            Node<T> currentNode = this.head;
            currentNode.next = this.head;
            this.size--;
        } else if (this.size > 2) {
            Node<T> currentNode = this.head;
            Node<T> prevNode = this.head;

            for (int i = 0; i < this.size -2; i++) {
                prevNode = prevNode.next;
            }
            prevNode.next = currentNode;
            this.size--;
        }
    }

    /*
     * contains
     *
     * Check to see if the list contains a node with the specified data
     *
     * data - T; the data to check for
     *
     * Note: You should use x.equals(y) to compare generic data
     */
    public boolean contains(T data)
    {
        if (this.head == null) {
            return false;
        } else {
            Node<T> currentNode = this.head;
            while (true) {
                if (data.equals(currentNode.data)) {
                    return true;
                }
                if (currentNode.next.equals(this.head)) {
                    return false;
                }
                currentNode = currentNode.next;
            }
        }
    }

    /*
     * getIndex
     *
     * Return the index of the first node in the list with the specified data
     * or -1 if it does not exist
     *
     * data - T; the data to check for
     *
     * Note: You should use x.equals(y) to compare generic data
     */
    public int getIndex(T data)
    {
        if (this.head == null) {
            return -1;
        } else {
            Node<T> currentNode = this.head;
            int i = 0;

            for (int j = 0; j < this.size; j++) {
                if (data.equals(currentNode.data)) {
                    return i;
                }
                currentNode = currentNode.next;
                i++;
            }
            return -1;
        }
    }

    /*
     * getElementAtIndex
     *
     * Return the node at the specified index or null if it is out of range
     *
     * index - int; the desired index
     */
    public Node<T> getElementAtIndex(int index)
    {
        if (index >= 0 && index < this.size) {
            Node<T> currentNode = this.head;

            if (index == 0) {
                return currentNode;
            } else {
                for (int i = 0; i < index; i++) {
                    currentNode = currentNode.next;
                }
                return currentNode;
            }
        }
        return null;
    }

    /*
     * clear
     *
     * Clear the linked list
     */
    public void clear()
    {
        if (this.head != null) {
            Node<T> currentNode = this.head;

            do {
                currentNode.data = null;
                currentNode = currentNode.next;
            } while (!currentNode.equals(this.head));
            this.size = 0;
        }
    }

    /*
     * isEmpty
     *
     * Return whether or not the list is empty
     */
    public boolean isEmpty()
    {
        if (this.head == null) {
            return true;
        } else {
            return false;
        }
    }

    /*
     * getHead
     *
     * Return the head node (possibly null)
     */
    public Node<T> getHead()
    {
        return this.head;
    }

    /*
     * getSize
     *
     * Return the number of elements in the linked list
     */
    public int getSize()
    {
        return this.size;
    }

    /*
     * toString
     *
     * Return a string representation of the circular linked list
     *
     * Note: We will not be grading this, it is only for you to be able to
     *       easily display the contents of a list by using something
     *       like "System.out.println(cll);". Remember not to have any printed
     *       output in any of the other methods.
     */
    public String toString()
    {
        return "";
    }

    /*
     * Node<T> class
     *
     * This class describes a generic node object.
     *
     * You should not edit anything below this line but please note exactly what
     * is implemented so that you can use it in your linked list code
     */
    public class Node<T>
    {
        private Node<T> prev, next;
        private T data;

        public Node(T data)
        {
            this.data = data;
        }

        public void setNext(Node<T> next)
        {
            this.next = next;
        }

        public void setPrev(Node<T> prev)
        {
            this.prev = prev;
        }

        public void setData(T data)
        {
            this.data = data;
        }

        public Node<T> getNext()
        {
            return this.next;
        }

        public Node<T> getPrev()
        {
            return this.prev;
        }

        public T getData()
        {
            return this.data;
        }

        public void clearNext()
        {
            this.next = null;
        }

        public void clearPrev()
        {
            this.prev = null;
        }
    }
}
