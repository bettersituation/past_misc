/*
 * Name: 조태희
 * Student ID: 2011131055
 */

/*
 * You should not import anything or change/add any instance variables, methods,
 * or method signatures.
 */
public class LinkedList<T>
{

    private int size;
    private Node<T> head, tail;

    /*
     * Constructor for our Linked List
     *
     * Initialize the instance variables to their default values
     */
    public LinkedList()
    {
        head = null;
        tail = null;
        size = 0;
    }

    /*
     * insert
     *
     * Insert a new node with the specified data into the specified index
     *
     * index - int; the location in which to insert the new node (indexed
     *              from 0)
     *
     * data - T; the data to be stored in the newly created node
     *
     * Note:  If the index is out of range ([0, size]), nothing should be
     *        inserted.
     */
    public void insert(int index, T data)
    {   
        if (index >= 0 && index <= this.size) {
            
            if (index == 0) {
                this.insertAtHead(data);
            } else if (index == this.size) {
                this.insertAtTail(data);
            
            } else {
                Node<T> newNode = new Node<T>(data);
                Node<T> currentNode = this.head;
                Node<T> prevNode = this.head;

                for (int i = 0; i < index; i++) {
                    prevNode = currentNode;
                    currentNode = currentNode.next;
                }

                prevNode.next = newNode;
                newNode.next = currentNode;
            }

            this.size++;
        }
    }

    /*
     * insertAtHead
     *
     * Insert a new node at the head with the specified data
     *
     * data - T; the data to be stored in the newly created node
     *
     * Note: This should insert even if the list is empty.
     */
    
    public void insertAtHead(T data)
    {
        Node<T> newNode = new Node<T>(data);
        newNode.setNext(this.head);
        this.head = newNode;
        this.size++;
    }

    /*
     * insertAtTail
     *
     * Insert a new node at the tail with the specified data
     *
     * data - T; the data to be stored in the newly created node
     *
     * Note: This should insert even if the list is empty.
     */
    
    public void insertAtTail(T data)
    {
        Node<T> newNode = new Node<T>(data);

        if (this.head != null) {
            Node<T> currentNode = this.head;

            while (true) {
                if (currentNode.next == null) {
                    break;
                }
                currentNode = currentNode.next;
            }

            currentNode.next = newNode;
            this.tail = newNode;
            this.size++;
            
        } else {
            this.head = newNode;
            this.tail = newNode;
            this.size++;
        }
    }

    /*
     * remove
     *
     * Remove the first node with the specified data, if it exists
     *
     * data - T; the data to find and remove from the list
     *
     * Note: You should use x.equals(y) to compare generic data
     */

    public void remove(T data)
    {   
        if (this.head != null) {
            Node<T> currentNode = this.head;
            
            if (data.equals(currentNode.data)) {
                if (this.size == 1) {
                    this.head = null;
                    this.tail = null;
                    this.size--;
                } else {
                    currentNode = currentNode.next;
                    this.head = currentNode;
                    this.size--;
                }

            } else {
                int i = 0;
                boolean e = false;

                while(true) {
                    if (data.equals(currentNode.data)) {
                        e = true;
                        break;
                    }
                    if (currentNode.next == null) {
                        break;
                    }
                    currentNode = currentNode.next;
                    i++;
                }

                if (e) {
                    Node<T> prevNode = this.head;
                    for (int j = 0; j < i -1; j++) {
                        prevNode = prevNode.next;
                    }
                    prevNode.next = currentNode.next;
                    this.size--;
                }
            }
        }
    }

    /*
     * removeIndex
     *
     * Remove the node at the specified index
     *
     * index - int; the index to remove from
     *
     * Note: If the index is out of range do nothing
     */
    public void removeIndex(int index)
    {
        if (index >= 0 && index < this.size) {
            Node<T> currentNode = this.head;

            if (index == 0) {
                this.head = currentNode.next;
                currentNode.next = null;
                this.size--;

            } else {
                Node<T> prevNode = this.head;

                for (int i = 0; i < index -1; i++) {
                    prevNode = prevNode.next;
                    currentNode = currentNode.next;
                }
                currentNode = currentNode.next;
                currentNode = currentNode.next;

                prevNode.next = currentNode;
                this.size--;
            }
        }
    }

    /*
     * removeFromHead
     *
     * Remove the head node of the list, if it exists
     */
    public void removeFromHead()
    {
        if (this.head != null) {
            Node<T> currentNode = this.head;
            Node<T> prevNode = this.head;
            currentNode = currentNode.next;
            prevNode.next = null;
            this.head = currentNode;
            this.size--;
        }
    }

    /*
     * removeFromTail
     *
     * Remove the tail node of the list, if it exists
     */
    public void removeFromTail()
    {
        if (this.head != null) {
            Node<T> currentNode = this.head;
            Node<T> prevNode = this.head;
            
            while (true) {
                if (currentNode.next == null) {
                    break;
                }
                prevNode = currentNode;
                currentNode = currentNode.next;
            }
            prevNode.next = null;
            this.tail = prevNode;
        }
    }

    /*
     * joinLists
     *
     * Append a second list to the current list
     *
     * ll - LinkedList<T>; the linked list to append to the current list
     *
     * Note: This should work even if one or both of the lists are empty
     */
    public void joinLists(LinkedList<T> ll)
    {
        Node<T> tailNode = this.tail;
        Node<T> lltailNode = ll.tail;
        if (tailNode != null) {
            tailNode.next = ll.head;

            if (lltailNode != null) {
                this.tail = lltailNode;
            }

        } else {
            this.head = ll.head;
            this.tail = ll.tail;
            this.size += ll.size;
        }
        ll.clear();
    }

    /*
     * contains
     *
     * Check to see if the list contains a node with the specified data
     *
     * data - T; the data to check for
     *
     * Note: You should use x.equals(y) to compare generic data
     */
    public boolean contains(T data)
    {   
        if (this.head != null) {
            Node<T> currentNode = this.head;
            while (true) {
                if (data.equals(currentNode.data)) {
                    return true;
                }

                if (currentNode.next == null) {
                    return false;
                }

                currentNode = currentNode.next;
            }
        }
        return false;
    }

    /*
     * getIndex
     *
     * Return the index of the first node in the list with the specified data
     * or -1 if it does not exist
     *
     * data - T; the data to check for
     *
     * Note: You should use x.equals(y) to compare generic data
     */
    public int getIndex(T data)
    {
        if (this.head == null) {
            return -1;
        
        } else {
            int i = 0;
            Node<T> currentNode = this.head;

            while (true) {
                if (data.equals(currentNode.data)) {
                    return i;
                }

                if (currentNode.next == null) {
                    return -1;
                }

                currentNode = currentNode.next;
                i++;
            }
        }
    }

    /*
     * getElementAtIndex
     *
     * Return the node at the specified index or null if it is out of range
     *
     * index - int; the desired index
     */
    public Node<T> getElementAtIndex(int index)
    {
        if (this.head != null) {
            if (index >= 0 && index < this.size) {
                Node<T> currentNode = this.head;
                if (index == 0) {
                    return currentNode;
                } else {
                    for (int i = 0; i < index; i++) {
                        currentNode = currentNode.next;
                    }
                    return currentNode;
                }
            }
        }
        return null;
    }

    /*
     * clear
     *
     * Clear the linked list
     */
    public void clear()
    {
        if (this.head != null) {
            Node<T> currentNode = this.head;
            while (true) {
                currentNode.data = null;
                currentNode = currentNode.next;

                if (currentNode == null) {
                    break;
                }
            }
            this.head = null;
            this.tail = null;
            this.size = 0;
        }
    }

    /*
     * isEmpty
     *
     * Return whether or not the list is empty
     */
    public boolean isEmpty()
    {
        if (this.head == null) {
            return true;
        } else {
            Node<T> currentNode = this.head;
            
            while (true) {
                
                if (currentNode.data != null) {
                    return false;
                }

                if (currentNode.next == null) {
                    return true;
                } else {
                    currentNode = currentNode.next;
                }
            }
        }
    }

    /*
     * getHead
     *
     * Return the head node (possibly null)
     */
    public Node<T> getHead()
    {
        return this.head;
    }

    /*
     * getTail
     *
     * Return the tail node (possibly null)
     */
    public Node<T> getTail()
    {
        return this.tail;
    }

    /*
     * getSize
     *
     * Return the number of elements in the linked list
     */
    public int getSize()
    {
        return this.size;
    }

    /*
     * toString
     *
     * Return a string representation of the linked list
     *
     * Note: We will not be grading this, it is only for you to be able to
     *       easily display the contents of a linked list by using something
     *       like "System.out.println(ll);". Remember not to have any printed
     *       output in any of the other methods.
     */
    public String toString()
    {
        return "";
    }

    /*
     * Node<T> class
     *
     * This class describes a generic node object.
     *
     * You should not edit anything below this line but please note exactly what
     * is implemented so that you can use it in your linked list code
     */
    public class Node<T>
    {
        private Node<T> next;
        private T data;

        public Node(T data)
        {
            this.data = data;
        }

        public void setNext(Node<T> next)
        {
            this.next = next;
        }

        public void setData(T data)
        {
            this.data = data;
        }

        public Node<T> getNext()
        {
            return this.next;
        }

        public T getData()
        {
            return this.data;
        }

        public void clearNext()
        {
            this.next = null;
        }
    }
}
