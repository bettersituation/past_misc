/*
 * Name: 조태희
 * Student ID: 2011131055
 */


/*
 * You should NOT import anything else.
 * 
 * For a quick summary of ArrayLists, see https://www.tutorialspoint.com/java/util/java_util_arraylist.htm
 */

import java.lang.Math;
import java.util.ArrayList;

public class Tree<T>
{

    /*
     * Instance variables
     *
     * You may add new instance variables and methods, but you should not
     * modify the variables and methods that are already defined.
     * 
     * size holds the number of elements currently in the tree
     * 
     * k holds the number of children a node can have
     * 
     * root holds the root node of the tree
     */
    private int size, k;
    private Node<T> root;

    /*
     * Constructor for the tree
     *
     * Initialize the instance variables to their default values
     * 
     * The default value for k is 2, meaning it is a binary tree
     */
    public Tree()
    {
        size = 0;
        k = 2;
        root = new Node<T>(null, null, k);
    }

    /*
     * Constructor for the tree
     *
     * k - int; the number of children a node can have
     * 
     * Note: If k = 2, it is considered a binary tree
     * 
     * Note: k will always be an integer greater than or equal to 2.
     *       You do not have to consider edge cases where an invalid
     *       value for k is passed as an input.
     */
    public Tree(int k)
    {
        size = 0;

        this.k = k;
        if (k < 2)
            this.k = 2;

        root = new Node<T>(null, null, this.k);
    }


    /*
     * insert
     *
     * Insert the data into the next available position
     * 
     * data - T; the data to be inserted
     * 
     * Note: The data should be inserted into the next available slot.
     *       Remember that the tree must always be complete, meaning
     *       each level must be full before starting on a new level and
     *       nodes are always added from left to right
     */
    public void insert(T data)
    {
        this.size++;

        if (this.size == 1)
        {
            this.getRoot().data = data;
        }

        else
        {
            Node<T> car = this.getRoot();
            int depth = this.getDepth();
            int temp = this.size;
            int mul = 1;

            ArrayList<Integer> path = new ArrayList<Integer>(depth -1);

            for (int i = 0; i < depth -1; i++) 
            {
                temp = temp - mul;
                mul *= this.k;
            }

            for (int i = 0; i < depth -1; i++)
            {
                mul = mul/this.k;
                path.add(temp/mul);
                temp = temp%mul;
            }

            if (depth == 2)
                car.addChild(data);
            
            if (depth > 2)
            {
                for (int i = 0; i < depth -2; i++) 
                {
                    car = car.getChildren().get(path.get(i));
                }

                car.addChild(data);
            }
        }
    }

    /*
     * remove
     *
     * Remove the "last" node in the tree
     * 
     * Note: The tree must always be complete, so you this method should
     *       remove the right most node in the lowest level of the tree.
     */
    public void remove()
    {
        if (this.size == 0)
            return;
        
        if (this.size == 1)
        {
            this.getRoot().data = null;
            size--;
            return;
        }

        Node<T> car = this.getRoot();
        int depth = this.getDepth();
        int temp = this.size;
        int mul = 1;

        ArrayList<Integer> path = new ArrayList<Integer>(depth -1);

        for (int i = 0; i < depth -1; i++) 
        {
            temp = temp - mul;
            mul *= this.k;
        }

        for (int i = 0; i < depth -1; i++)
        {
            mul = mul/this.k;
            path.add(temp/mul);

            temp = temp%mul;
        }

        if (depth == 2)
        {
            car.removeChild();
            size--;
            return;
        }

        for (int i = 0 ; i < depth -2; i++) 
        {
            car = car.getChildren().get(path.get(i));
        }

        car.removeChild();
        size--;
    }

    /*
     * preorder
     *
     * Return an arraylist of the nodes in the tree in preorder traversal order
     * 
     * Note: This should be implemented for all values of k.
     * 
     * Note: If the tree is empty, return null.
     */
    public ArrayList<Node<T>> preorder()
    {
        if (this.size == 0)
            return null;

        Node<T> car = this.getRoot();
        ArrayList<Node<T>> result = new ArrayList<Node<T>>();
        ArrayList<Integer> path = new ArrayList<Integer>();
        int sum = 0;
        int nth = 1;

        result.add(car);

        if (this.size == 1)
            return result;

        while (car.getChildren().size() > 0)
        {
            car = car.getChildren().get(0);
            
            if (car.getChildren().size() > 0)
            {
                result.add(car);
                path.add(0);
            }

            else
            {
                car = car.getParent();
                break;
            }
        }

        while (true)
        {
            for (int i = 0; i < car.getChildren().size(); i++)
            {
                result.add(car.getChildren().get(i));    
            }

            for (int i = 0; i < path.size() ; i++)
            {
                if (path.get(path.size() -1 -i) == this.k -1)
                {
                    path.set(path.size() -1 -i, 0);
                    nth++;
                }

                else
                {
                    path.set(path.size() -1 -i, path.get(path.size() -1 -i) +1);
                    break;
                }
            }

            for (int i = 0; i < path.size(); i++)
            {
                sum += path.get(i);
            }

            if (sum == 0)
                return result;

            for (int i = 0; i < nth; i++)
            {
                car = car.getParent();
            }

            for (int i = 0; i < nth; i++)
            {
                car = car.getChildren().get(path.get(path.size() -nth +i));

                if (car.getChildren().size() > 0)
                {
                    result.add(car);
                }

                else
                {
                    car = car.getParent();
                    path.remove(path.size() -1);
                }
            }

            sum = 0;
            nth = 1;
        }
    }

    /*
     * postorder
     *
     * Return an arraylist of the nodes in the tree in postorder traversal order
     * 
     * Note: This should be implemented for all values of k.
     * 
     * Note: If the tree is empty, return null.
     */
    public ArrayList<Node<T>> postorder()
    {
        if (this.size == 0)
            return null;

        Node<T> car = this.getRoot();
        ArrayList<Node<T>> result = new ArrayList<Node<T>>();
        ArrayList<Integer> path = new ArrayList<Integer>();
        int sum = 0;
        int nth = 1;

        if (this.size == 1)
        {
            result.add(car);
            return result;
        }

        while (car.getChildren().size() > 0)
        {
            car = car.getChildren().get(0);
            
            if (car.getChildren().size() > 0)
                path.add(0);

            else
            {
                car = car.getParent();
                break;
            }
        }

        while (true)
        {
            for (int i = 0; i < car.getChildren().size(); i++)
            {
                result.add(car.getChildren().get(i));    
            }

            for (int i = 0; i < path.size() ; i++)
            {
                if (path.get(path.size() -1 -i) == this.k -1)
                {
                    path.set(path.size() -1 -i, 0);
                    nth++;
                }

                else
                {
                    path.set(path.size() -1 -i, path.get(path.size() -1 -i) +1);
                    break;
                }
            }

            result.add(car);

            if (nth > 1)
            {
                for (int i = 0; i < nth -1; i++)
                {
                    car = car.getParent();
                }

                result.add(car);
            }

            car = car.getParent();

            for (int i = 0; i < path.size(); i++)
            {
                sum += path.get(i);
            }

            if (sum == 0)
            {
                result.add(this.getRoot());
                return result;
            }

            for (int i = 0; i < nth; i++)
            {
                car = car.getChildren().get(path.get(path.size() -nth +i));

                if (car.getChildren().size() == 0)
                {
                    car = car.getParent();
                    path.remove(path.size() -1);
                }
            }

            sum = 0;
            nth = 1;
        }
    }

    /*
     * inorder
     *
     * Return an arraylist of the nodes in the tree in inorder traversal order
     * 
     * Note: This should be implemented only for binary trees. If the
     *       tree is not a binary tree, you should return null.
     * 
     * Note: If the tree is empty, return null.
     */
    public ArrayList<Node<T>> inorder()
    {
        if (this.k != 2)
            return null;

        if (this.size == 0)
            return null;

        ArrayList<Node<T>> result = new ArrayList<Node<T>>();
        ArrayList<Integer> path = new ArrayList<Integer>();
        Node<T> car = this.getRoot();
        int sum = 0;
        int nth = 1;

        if (this.size == 1)
        {
            result.add(car);
            return result;
        }

        while (car.getChildren().size() > 0)
        {
            car = car.getChildren().get(0);
            
            if (car.getChildren().size() > 0)
                path.add(0);

            else
            {
                car = car.getParent();
                break;
            }
        }

        while (true)
        {
            if (car.getChildren().size() == 1)
            {
                result.add(car.getChildren().get(0));
                result.add(car);
            }

            else
            {
                result.add(car.getChildren().get(0));
                result.add(car);
                result.add(car.getChildren().get(1));
            }

            for (int i = 0; i < path.size() ; i++)
            {
                if (path.get(path.size() -1 -i) == 1)
                {
                    path.set(path.size() -1 -i, 0);
                    nth++;
                }

                else
                {
                    path.set(path.size() -1 -i, 1);
                    break;
                }
            }

            for (int i = 0; i < nth; i++)
            {
                car = car.getParent();
            }

            result.add(car);

            for (int i = 0; i < path.size(); i++)
            {
                sum += path.get(i);
            }

            if (sum == 0)
                return result;

            for (int i = 0; i < nth; i++)
            {
                car = car.getChildren().get(path.get(path.size() -nth +i));

                if (car.getChildren().size() == 0)
                {
                    car = car.getParent();
                    path.remove(path.size() -1);
                }
            }            

            nth = 1;
            sum = 0;
        }
    }

    /*
     * convertToArrayList
     *
     * Return an ArrayList representing the tree.
     * 
     * Note: See page 19 of Lecture 5 for information.
     * 
     * Note: This should be implemented for all values of k. For example,
     *       the children of a node at index i in a k-ary tree should
     *       be stored from index k*i+1 to index k*i+k. The root should be
     *       at index 0.
     * 
     * Note: If the tree is empty, return null.
     * 
     */
    public ArrayList<Node<T>> convertToArrayList()
    {
        if (this.size == 0)
            return null;

        ArrayList<Node<T>> result = new ArrayList<Node<T>>();
        Node<T> car = this.getRoot();

        result.add(car);
        
        if (this.size == 1)
            return result;

        ArrayList<Integer> search = new ArrayList<Integer>();
        boolean digit = true;
        int nth = 1;

        for (int i = 0; i < car.getChildren().size(); i++) 
        {
            result.add(car.getChildren().get(i));
        }

        search.add(0);

        while (true)
        {
            if (car.getChildren().size() == 0)
                return result;

            for (int i = 0; i < car.getChildren().size(); i++)
            {
                result.add(car.getChildren().get(i));
            }

            if (search.get(0) < this.k -1)
                search.set(0, search.get(0) +1);

            else
            {
                for (int i = 0; i < search.size(); i++) 
                {
                    if (search.get(i) == k -1)
                    {
                        search.set(i, 0);
                        nth ++;
                    }

                    else
                    {
                        search.set(i, search.get(i) +1);
                        break;
                    }
                }

                for (int i = 0; i < search.size(); i++)
                {
                    if (search.get(i) != 0)
                        digit = false;
                }

                if (digit)
                    search.add(0);

                if (digit)
                {
                    car = this.getRoot();

                    for (int i = 0; i < search.size(); i++)
                    {
                        car = car.getChildren().get(0);    
                    }
                }

                else
                {
                    for (int i = 0; i < nth; i++)
                    {
                        car = car.getParent();    
                    }

                    for (int i = 0; i < nth; i++)
                    {
                        car = car.getChildren().get(search.get(nth -1 -i));    
                    }
                }

                digit = true;
                nth = 1;
            }
        }
    }

    /*
     * getSize
     *
     * Return the number of elements in the tree
     */
    public int getSize()
    {
        return this.size;
    }

    /*
     * clear
     *
     * Clear the tree
     */
    public void clear()
    {
        this.root = new Node(null, null, this.k);
    }

    /*
     * contains
     * 
     * data - T; the data to be searched for
     *
     * Return true if there is a node in the tree with the specified data and
     * false otherwise.
     */
    public boolean contains(T data)
    {
        ArrayList<Node<T>> entries = this.convertToArrayList();

        if (entries == null)
            return false;

        for (int i = 0; i < entries.size(); i++)
        {
            if (entries.get(i).getData().equals(data))
            {
                return true;   
            }
        }

        return false;
    }

    /*
     * getDepth
     *
     * Return the number of levels in the tree.
     * 
     * Note: The root node counts as one level. The only tree with depth
     *       equal to 0 is the empty tree.
     */
    public int getDepth()
    {
        if (this.size == 0)
            return 0;

        int depth = 1;
        int mul = 1;
        int temp = this.size;

        while (true)
        {
            temp = temp - mul;

            if (temp <= 0)
                return depth;

            mul *= this.k;
            depth++;
        }
    }

    /*
     * isPerfect
     *
     * Return true if the tree is currently perfect and false otherwise.
     * 
     * Note: A perfect tree is a complete binary tree where all of the levels
     *       are full. In other words, inserting a node into this tree would
     *       force it to begin another level.
     * 
     * Note: The empty tree is perfect.
     */
    public boolean isPerfect()
    {
        if (this.size == 0)
            return true;

        int mul = 1;
        int temp = this.size;

        while (true)
        {
            temp = temp - mul;

            if (temp == 0)
                return true;

            if (temp < 0)
                return false;

            mul *= this.k;
        }
    }

    /*
     * getLast
     *
     * Return the right most node in the lowest level of the tree
     * 
     * Note: If the tree is empty, return null.
     */   
    public Node<T> getLast()
    {
        int depth = this.getDepth();

        if (depth == 0)
            return null;

        if (depth == 1)
            return this.getRoot();

        ArrayList<Integer> path = new ArrayList<Integer>(depth -1);

        int temp = this.size;
        int mul = 1;
        Node<T> car = this.getRoot();

        for (int i = 0; i < depth -1; i++) 
        {
            temp = temp - mul;
            mul *= this.k;
        }

        for (int i = 0; i < depth -1; i++)
        {
            mul = mul/this.k;
            path.set(i, temp/mul);

            temp = temp%mul;
        }

        for (int i = 0; i < depth -1; i++) 
        {
            car = car.getChildren().get(path.get(i));
        }

        return car;
    }

    /*
     * getRoot
     *
     * Return the root of the tree
     */   
    public Node<T> getRoot()
    {
        return this.root;
    }

    /*
    * You should NOT change anything below this line.
    * 
    * Pay close attention to what has been implemented already and
    * what you need to implement on your own (in the Tree class).
    */
    public class Node<T>
    {
        private T data;
        private Node<T> parent;
        private ArrayList<Node<T>> children;
        //This arraylist contains the children of the node in order from left to right

        public Node(T data, Node<T> parent, int k)
        {
            this.parent = parent;
            this.data = data;
            children = new ArrayList<Node<T>>(k);
        }

        public Node<T> getParent()
        {
            return this.parent;
        }

        public T getData()
        {
            return this.data;
        }

        public ArrayList<Node<T>> getChildren()
        {
            return children;
        }
        
        /*
         * This will append to the end of the children arraylist.
         * You need to perform the bounds checks yourself for when
         * the node has the maximum amount of children.
         */
        public void addChild(T data)
        {
            children.add(new Node<T>(data, this, k));
        }

        /*
         * This will remove the right most child of the current node,
         * if it exists.
         */
        public void removeChild()
        {
            if(children.size() > 0)
                children.remove(children.size()-1);
        }

        public void setParent(Node<T> n)
        {
            parent = n;
        }

        public void clearParent()
        {
            parent = null;
        }
    }
}