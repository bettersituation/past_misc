/*
 * Name: 조태희
 * Student ID: 2011131055
 */

public class PostfixCalculator
{

   /*
    * Instance variables
    *
    * You should not add anything here or change the existing ones.
    *
    * You do not need to use all of these
    */
    Queue<String> sq;
    Queue<Integer> iq;
    Stack<String> ss;
    Stack<Integer> is;

    /*
     * Constructor for the StackSolver
     *
     * Initialize the instance variables to their default values
     * You do not have to initialize variables you will not use
     */
    public PostfixCalculator()
    {
        is = new Stack<Integer>();
    }


    /*
     * evaluate
     *
     * Evaluate the expression and return the result
     *
     * exp - String; the string representation of the postfix expression
     *
     * Note: We guarantee exp will always be a valid postfix expression of
     *       length >= 1. Only operators +, -, and * will be used and only
     *       non-negative integers will be used as terms. Terms and operators
     *       will be separated by spaces, for example "5 3 x". At no point in
     *       the evaluation will an intermediate value be large enough to
     *       overflow the Java int type. However, it can go below 0.
     */
    public int evaluate(String exp)
    {
        String tmp = "";
        int result = 0;

        for (int i = 0; i < exp.length(); i++)
        {

            if (exp.charAt(i) == " ".charAt(0))
            {
                try
                {
                    is.push(Integer.parseInt(tmp));
                }

                catch (Exception e)
                {

                    switch (tmp)
                    {
                        case "+" :
                            result = is.pop() + is.pop();
                            break;

                        case "-" :
                            result = - is.pop() + is.pop();
                            break;

                        case "x" :
                            result = is.pop() * is.pop();
                            break;
                    }

                    is.push(result);
                }

                tmp = "";
            }

            else
            {
                tmp += exp.charAt(i);
            }
        }


        try
        {
            is.push(Integer.parseInt(tmp));
        }

        catch (Exception e)
        {

            switch (tmp)
            {
                case "+" :
                    result = is.pop() + is.pop();
                    break;

                case "-" :
                    result = - is.pop() + is.pop();
                    break;

                case "x" :
                    result = is.pop() * is.pop();
                    break;
            }

            is.push(result);
        }

        return is.pop();
    }
}