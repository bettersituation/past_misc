/*
 * Name: 조태희
 * Student ID: 2011131055
 */

/*
 * Do not import anything
 */

public class Sorter
{

    public Sorter()
    {
        /*
         * Constructor for our sorter
         * In this assignment you do not have to implement anything here
         * so just leave this method blank
         */
    }

    public int[] ascending(int[] input)
    {   
        if (input.length != 0) {
            int idx = -1;
            // for locating index of min
            int min = -1;
            // for locating value of min

            for (int i = 0; i < input.length -1; i++) {
                min = input[i];

                for (int j = i + 1; j < input.length; j++) {
                    if (input[j] < min) {
                        min = input[j];
                        idx = j;
                    }
                }
                input[idx] = input[i];
                input[i] = min;
            }
        }
        return input;
    }

    public int[] descending(int[] input)
    {
        if (input.length != 0) {
            int idx = -1;
            // for locating index of max
            int max = -1;
            // for locating value of max

            for (int i = 0; i < input.length -1; i++) {
                max = input[i];

                for (int j = i + 1; j < input.length; j++) {
                    if (input[j] > max) {
                        max = input[j];
                        idx = j;
                    }
                }
                input[idx] = input[i];
                input[i] = max;
            }
        }
        return input;
    }
}
