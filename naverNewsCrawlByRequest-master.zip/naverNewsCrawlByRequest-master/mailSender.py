# -*- coding: utf-8 -*-

import os
from smtplib import SMTP
from email import encoders
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart


class Email_sender() :

    def __init__(self, user_id, user_pwd,  to = [], subject = '', body = '', attach_path = [], base64_yn = True):
        self.sender = user_id
        self.pwd = user_pwd
        self.to = to
        self.subject = subject
        self.body = body
        self.attach_path = attach_path
        self.base64_yn = base64_yn
        self.frame = MIMEMultipart()

    def make_email(self) :
        self.frame['From'] = self.sender
        self.frame['To'] = ', '.join(self.to)
        self.frame['Subject'] = self.subject
        self.frame.attach(MIMEText(self.body, 'plain'))
        self.frame.preamble = 'Can\'t see email if this is a mime aware reader.\n'

        for file in self.attach_path :
            with open(file, 'rb') as fp :
                msg = MIMEBase('application', 'vnd.openxmlformats-officedocument.spreadsheetml.sheet', name = os.path.basename(file))
                msg.set_payload(fp.read())
            encoders.encode_base64(msg)
            msg.add_header('Content-Disposition', 'attachment', filename = os.path.basename(file))
            self.frame.attach(msg)

        self.composed = self.frame.as_string()

    def send_email(self):
        with SMTP('smtp.gmail.com', 587) as s :
            s.ehlo()
            s.starttls()
            s.ehlo()
            s.login(self.sender, self.pwd)
            s.sendmail(self.sender, self.to, self.composed)
            s.close()
