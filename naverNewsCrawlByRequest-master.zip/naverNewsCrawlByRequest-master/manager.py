# -*- coding: utf-8 -*-

import userInfo
import mailReceiver
import mailSender
import naverNewsSearch
import pandas as pd
import time
import os

subject_false = '제목에는 네이버와 뉴스가 포함되어야 해요'
body_false = '내용은 처음에 우선 한 칸 띄어주시고 검색어 먼저, 다음 줄에 검색 페이지 수를 써주세요\n예시\n========\n\n이란 핵\n4\n트럼프\n2\n\n\n시소의 원리\n6\n========\n다른 말은 쓰지 말아주세요'

mailReceiver.login(userInfo.user_id, userInfo.user_pwd)

while True:
    time.sleep(5)
    try:
        mailReceiver.update()
        mailList = mailReceiver.loop()
    except:
        try:
            mailReceiver.login(userInfo.user_id, userInfo.user_pwd)
            continue
        except:
            continue

    if not mailList:
        continue

    for mail in mailList:
        if (mail['Subject'] == False) or (mail['Body'] == False):
            sender = mailSender.Email_sender(userInfo.user_id, userInfo.user_pwd, to = [mail['From']], subject = subject_false, body = body_false, base64_yn = mail['base64_yn'])
            sender.make_email()
            sender.send_email()

        else:
            xlsxWriter = pd.ExcelWriter('/tmp/searchResult.xlsx')
            for pair in mail['Body']:
                naverNewsSearch.make_df(pair[0], pair[1]).to_excel(xlsxWriter, pair[0], encoding = 'utf-8')
            xlsxWriter.save()

            sender = mailSender.Email_sender(userInfo.user_id, userInfo.user_pwd, to = [mail['From']], subject = 'Request OK', body = 'Request OK'
                                             , attach_path = ['/tmp/searchResult.xlsx'], base64_yn = mail['base64_yn'])
            sender.make_email()
            sender.send_email()
            os.remove('/tmp/searchResult.xlsx')
