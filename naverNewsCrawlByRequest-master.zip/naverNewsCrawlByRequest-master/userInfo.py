# -*- coding: utf-8 -*-

user_id = '@gmail.com'
user_pwd = ''
