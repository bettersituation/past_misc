# -*- coding: utf-8 -*-

import imaplib
import email
import base64, quopri, re

def encoded_words_to_text(encoded_words):
    encoded_word_regex = r'=\?{1}(.+)\?{1}([B|Q])\?{1}(.+)\?{1}='
    ss = re.match(encoded_word_regex, encoded_words)
    if ss == None:
        return encoded_words
    charset, encoding, encoded_text = ss.groups()
    if encoding is 'B':
        byte_string = base64.b64decode(encoded_text)
    elif encoding is 'Q':
        byte_string = quopri.decodestring(encoded_text)
    return byte_string.decode(charset)

def get_first_text_block(email_msg):
    maintype = email_msg.get_content_maintype()
    if maintype == 'multipart':
        for part in email_msg.get_payload():
            return get_first_text_block(part)
    elif maintype == 'text':
        return email_msg.get_payload()

def check_base64(email_msg):
    if email_msg.get_payload()[0]['Content-Transfer-Encoding'] == 'base64':
        return True
    return False

def get_str(email_msg):
    if check_base64(email_msg):
        return base64.b64decode(get_first_text_block(email_msg)).decode()
    else:
        return get_first_text_block(email_msg)

def trim_str(s):
    return re.sub('[\n\t\r]+', '\n', s)

def body_check(body):
    li = [el.strip() for el in body.split('\n') if el.strip() != ' ' and el.strip() != '']
    if len(li) % 2 == 1:
        return False
    keywords = li[::2]
    pages = li[1::2]

    for i in range(len(pages)):
        try:
            pages[i] = int(pages[i])
        except ValueError:
            return False
    return list(zip(keywords, pages))

def title_check(title):
    if ('네이버' not in title) or ('뉴스' not in title):
        return False
    return title

def login(user_id, user_pwd):
    global M
    M = imaplib.IMAP4_SSL('imap.gmail.com')
    M.login(user_id, user_pwd)
    M.select('INBOX')

def update():
    M.recent()
    M.select('INBOX')

def get_uid(criteria = 'UNSEEN'):
    if criteria == 'UNSEEN':
        rv, data = M.uid('search', None, '(UNSEEN)')
    else:
        rv, data = M.uid('search', None, criteria)
    return data[0].split()

def check_uid(li):
    if li == []:
        return False
    else:
        return True

def get_mail(uid):
    rv, data = M.uid('fetch', uid, '(RFC822)')
    return email.message_from_string(data[0][1].decode('utf-8'))

def get_mails(uids):
    mails = []
    for uid in uids:
        mails.append(get_mail(uid))
    return [
            {'From' : email.utils.parseaddr(mail['From'])[1]
             , 'Subject' : title_check(encoded_words_to_text(mail['Subject']))
             , 'Body' : body_check(trim_str(get_str(mail)))
             , 'base64_yn': check_base64(mail)} for mail in mails
            ]

def logout():
    M.logout()

def loop(criteria = 'UNSEEN'):
    update()
    uids = get_uid(criteria)
    if not check_uid(uids):
        return False
    return get_mails(uids)
