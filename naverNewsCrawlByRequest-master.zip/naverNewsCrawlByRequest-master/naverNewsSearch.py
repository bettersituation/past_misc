﻿# -*-coding: utf-8 -*-

from bs4 import BeautifulSoup as bs
import requests
import pandas as pd

headers = {
'authority': 's.pstatic.net',
'method': 'GET',
'path': '/imgshopping/static/sb/js/shopboxR0005_v1.js?v=2018041817',
'scheme': 'https',
'accept': '*/*',
'accept-encoding': 'gzip, deflate, br',
'accept-language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36'
}

def get_title(tag):
    return tag.get('title')

def get_content(tag):
    return tag.text

def get_titles(tag_list):
    return [get_title(tag) for tag in tag_list]

def get_contents(tag_list):
    return [get_content(tag) for tag in tag_list]

def check_empty(obj):
    if not obj.select('div.news.mynews.section > ul.type01'):
        return True
    return False

def path_to_titles(obj):
    return obj.select('div.news.mynews.section > ul.type01 > li > dl > dt > a')

def path_to_contents(obj):
    return obj.select('div.news.mynews.section > ul.type01 > li > dl > dd:nth-of-type(2)')

def to_titles(obj):
    return get_titles(path_to_titles(obj))

def to_contents(obj):
    return get_contents(path_to_contents(obj))

def to_news(obj):
    return [{'title' : title, 'content' : content } for title, content in zip(to_titles(obj), to_contents(obj))]

def get_url(keyword, page):
    pre_url = 'https://search.naver.com/search.naver?&where=news&query='
    post_url = '&sm=tab_pge&sort=0&photo=0&field=0&reporter_article=&pd=0&ds=&de=&docid=&nso=so:r,p:all,a:all&mynews=0&cluster_rank=&start={}&refresh_start=0'.format(1 + 10*(page-1))
    return pre_url + keyword + post_url

def get_page(keyword, page):
    url = get_url(keyword, page)
    return bs(requests.get(url, headers = headers).text, 'html.parser')

def get_page_news(keyword, page):
    return to_news(get_page(keyword, page))

def get_pages_news(keyword, page):
    r = []
    if check_empty(get_page(keyword, 1)):
        return [{'title': 'No', 'content': 'No'}]
    for i in range(1, page +1):
        r += get_page_news(keyword, i)
    return r

def get_fn(keyword, page):
    return 'tmp/' + keyword.replace(' ', '_') + '_to_page' + str(page) + '.xlsx'

def make_df(keyword, page):
    news = get_pages_news(keyword, page)
    df = pd.DataFrame(news)
    df['content'] = "'" + df['content']
    df['title'] = "'" + df['title']
    df = df[['title', 'content']]
    return df
